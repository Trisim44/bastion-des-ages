import pygame as pg
import random
import constants as c
from enemy_data import ENEMY_SPAWN_DATA

class World():
  def __init__(self, data, map_image):
    self.level = 1
    self.game_speed = 1
    self.projectile_group = pg.sprite.Group()
    self.health = c.HEALTH
    self.money = c.MONEY
    self.tile_map = []
    self.waypoints = []
    self.level_data = data
    self.image = map_image
    self.enemy_list = []
    self.spawned_enemies = 0
    self.killed_enemies = 0
    self.missed_enemies = 0
    self.enemy_list_by_level = ENEMY_SPAWN_DATA

  def process_data(self, scale_x, scale_y):
    coordinates = [
        {"x": 70, "y": -40},
        {"x": 70, "y": 5},
        {"x": 70, "y": 54},
        {"x": 78, "y": 70},
        {"x": 120, "y": 88},
        {"x": 124, "y": 88},
        {"x": 213, "y": 86},
        {"x": 248, "y": 76},
        {"x": 248, "y": 63},
        {"x": 248, "y": 48},
        {"x": 330, "y": 48},
        {"x": 335, "y": 50},
        {"x": 330, "y": 91},
        {"x": 334, "y": 123},
        {"x": 299, "y": 150},
        {"x": 278, "y": 158},
        {"x": 260, "y": 159},
        {"x": 223, "y": 155},
        {"x": 189, "y": 147},
        {"x": 101, "y": 147},
        {"x": 90, "y": 153},
        {"x": 84, "y": 168},
        {"x": 84, "y": 192},
        {"x": 88, "y": 209},
        {"x": 101, "y": 215},
        {"x": 197, "y": 215},
        {"x": 247, "y": 210},
        {"x": 280, "y": 225},
        {"x": 280, "y": 265},
        {"x": 278, "y": 300}
    ]
    self.waypoints = [(coord["x"] * scale_x, coord["y"] * scale_y) for coord in coordinates]

  def process_enemies(self):
    enemies = ENEMY_SPAWN_DATA[self.level - 1]
    for enemy_type in enemies:
        enemies_to_spawn = enemies[enemy_type]
        for enemy in range(enemies_to_spawn):
            self.enemy_list.append(enemy_type)
    random.shuffle(self.enemy_list)

  def check_level_complete(self):
    return (self.killed_enemies + self.missed_enemies) == len(self.enemy_list)

  def reset_level(self):
    self.enemy_list = []
    self.spawned_enemies = 0
    self.killed_enemies = 0
    self.missed_enemies = 0

  def draw(self, surface):
    surface.blit(self.image, (0, 0))
