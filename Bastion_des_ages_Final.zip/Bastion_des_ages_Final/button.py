import pygame as pg

import pygame as pg

class Button:
    def __init__(self, x, y, image, single_click=True):
        self.image = image
        self.rect = self.image.get_rect(topleft=(x, y))
        self.clicked = False
        self.single_click = single_click

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def handle_event(self, event):
        """Retourne True si le bouton a été cliqué avec cet événement"""
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if not self.clicked:
                    if self.single_click:
                        self.clicked = True
                    return True
        if event.type == pg.MOUSEBUTTONUP and event.button == 1:
            self.clicked = False
        return False

class ToggleButton:
    def __init__(self, x, y, spritesheet, num_flags=2, single_click=True):
        assert num_flags in (2, 3), "ToggleButton supporte uniquement 2 ou 3 états"

        self.num_flags = num_flags
        self.single_click = single_click
        self.clicked = False
        self.current_state = 0

        # Découpe des sous-images depuis le spritesheet
        self.width = spritesheet.get_width() // num_flags
        self.height = spritesheet.get_height()
        self.images = [
            spritesheet.subsurface((i * self.width, 0, self.width, self.height))
            for i in range(num_flags)
        ]
        self.rect = self.images[0].get_rect(topleft=(x, y))

    def draw(self, surface):
        surface.blit(self.images[self.current_state], self.rect)

    def handle_event(self, event):
        if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if not self.clicked:
                    if self.single_click:
                        self.clicked = True
                    self.current_state = (self.current_state + 1) % self.num_flags
                    return True
        if event.type == pg.MOUSEBUTTONUP and event.button == 1:
            self.clicked = False
        return False