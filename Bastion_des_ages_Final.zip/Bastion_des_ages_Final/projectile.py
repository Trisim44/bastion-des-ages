import pygame as pg
import math

class Projectile(pg.sprite.Sprite):
    def __init__(self, turret_type, start_pos, target_pos, damage, radius,
                 rock_frames, lance_sheet, rock_explosion_sheet,
                 scale_x, scale_y, game_speed,explosion,vol_rock1):
        super().__init__()
        self.turret_type = turret_type
        self.damage = damage
        self.radius = radius
        self.scale_x = scale_x
        self.scale_y = scale_y
        self.game_speed = game_speed
        self.pos = pg.math.Vector2(start_pos)
        self.target = pg.math.Vector2(target_pos)
        self.start_pos = pg.math.Vector2(start_pos)
        self.start_time = pg.time.get_ticks()
        self.exploding = False
        self.arrived = False
        self.explosion=explosion
        self.vol_rock=vol_rock1
        self.premierefois=True
        if turret_type == "defense":
            # Animation caillou
            self.frames = rock_frames
            self.frame_index = 0
            self.animation_timer = pg.time.get_ticks()
            self.animation_delay = 80
            self.image = self.frames[0]

            self.start_y = self.pos.y
            dy = self.target.y - self.start_pos.y
            base_height = 80 * self.scale_y
            extra_height = max(-dy, 0) * 0.4
            self.max_height = -(base_height + extra_height)
            self.flight_duration = 1

            # Explosion
            self.explosion_sheet = rock_explosion_sheet
            self.explosion_frames = self.slice_sheet(self.explosion_sheet, 6)
            self.explosion_index = 0
            if self.explosion_frames:
                explosion_frame = self.explosion_frames[0]
                self.radius = (explosion_frame.get_width() // 2 + explosion_frame.get_height() // 2) // 2

        elif turret_type == "artillerie":
            # Image fixe selon direction
            self.image = self.get_lance_image(lance_sheet, start_pos, target_pos, scale_x, scale_y)
            self.velocity = (self.target - self.pos).normalize() * 15
        else:
            raise ValueError(f"Projectile type inconnu : {turret_type}")

        self.rect = self.image.get_rect(center=self.pos)

    def slice_sheet(self, sheet, num_frames):
        frame_w = sheet.get_width() // num_frames
        frame_h = sheet.get_height()
        return [pg.transform.scale(sheet.subsurface((i * frame_w, 0, frame_w, frame_h)),
                (int(frame_w * self.scale_x), int(frame_h * self.scale_y))) for i in range(num_frames)]

    def get_lance_image(self, sheet, start, target, scale_x, scale_y):
        dx = target[0] - start[0]
        dy = target[1] - start[1]
        angle = math.atan2(-dy, dx)

        direction_ranges = [
            (-7 * math.pi / 8, -5 * math.pi / 8),       # haut
            (-5 * math.pi / 8, -3 * math.pi / 8),       # haut droite
            (-3 * math.pi / 8, -math.pi / 8),           # droite
            (-math.pi / 8, math.pi / 8),                # bas droite
            (math.pi / 8, 3 * math.pi / 8),             # bas
            (3 * math.pi / 8, 5 * math.pi / 8),         # bas gauche
            (5 * math.pi / 8, 7 * math.pi / 8),         # gauche
            (7 * math.pi / 8, math.pi)                  # gauche haut
        ]
        direction_index = 0
        for i, (min_angle, max_angle) in enumerate(direction_ranges):
            if min_angle <= angle < max_angle:
                direction_index = i  # Décalage pour correspondre à l'ordre de la spritesheet
                break

        frame_width = sheet.get_width() // 8
        frame_height = sheet.get_height()
        frame = sheet.subsurface((direction_index * frame_width, 0, frame_width, frame_height))
        return pg.transform.scale(frame, (int(frame_width * scale_x), int(frame_height * scale_y)))

    def update(self, world, enemy_group):
        if self.turret_type == "defense":
            # Animation du caillou
            if not self.exploding:
                if self.premierefois:
                    self.vol_rock()
                    self.premierefois=False
                if pg.time.get_ticks() - self.animation_timer > (self.animation_delay / self.game_speed):
                    self.animation_timer = pg.time.get_ticks()
                    self.frame_index = (self.frame_index + 1) % len(self.frames)
                    self.image = self.frames[self.frame_index]

                elapsed = (pg.time.get_ticks() - self.start_time) / 1000
                t = min(elapsed / self.flight_duration, 1.0)
                self.pos = self.start_pos.lerp(self.target, t)

                target_y = self.target.y
                start_y = self.start_pos.y
                rect_y = start_y + (target_y - start_y) * t + self.max_height * math.sin(t * math.pi)
                self.rect.center = (self.pos.x, rect_y)

                if t >= 1.0:
                    self.explode(enemy_group)
                    self.exploding = True
                    self.explosion()

                    self.explosion_index = 0
                    self.animation_timer = pg.time.get_ticks()
            else:
                # Animation explosion
                if pg.time.get_ticks() - self.animation_timer > (self.animation_delay / self.game_speed):
                    self.animation_timer = pg.time.get_ticks()
                    if self.explosion_index < len(self.explosion_frames):
                        self.image = self.explosion_frames[self.explosion_index]
                        self.rect = self.image.get_rect(center=self.pos)
                        self.explosion_index += 1
                    else:
                        self.kill()

        elif self.turret_type == "artillerie":
            # Déplacement droit
            to_target = self.target - self.pos
            if to_target.length() < self.velocity.length():
                self.pos = self.target
                self.explode(enemy_group)
                self.kill()
            else:
                self.pos += self.velocity
                self.rect.center = self.pos

    def explode(self, enemy_group):
        explosion_rect = self.image.get_rect(center=self.pos)

        for enemy in enemy_group:
            if enemy.health > 0:
                enemy_rect = enemy.image.get_rect(center=enemy.pos)
                if explosion_rect.colliderect(enemy_rect):
                    enemy.health -= self.damage
                    if self.turret_type == "artillerie":
                        break


