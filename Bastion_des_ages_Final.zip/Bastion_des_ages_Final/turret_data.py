COLOSSE_DATA = [
    {
        #1
        "range" : 50,
        "cooldown" : 1300,
        "damage" : 50
    },
    {
        #2
        "range" : 100,
        "cooldown" : 1300,
    },
    {
        #3
        "range" : 120,
        "cooldown" : 1000,
    },
    {
        #4
        "range" : 150,
        "cooldown" : 800,
    },
    {
        #5
        "range" : 150,
        "cooldown" : 500,
    },
]

ARTILLERIE_DATA = [
    {
        #1
        "range" : 65,
        "cooldown" : 750,
        "damage" : 20
    },
    {
        #2
        "range" : 100,
        "cooldown" : 1300,
    },
    {
        #3
        "range" : 120,
        "cooldown" : 1000,
    },
    {
        #4
        "range" : 150,
        "cooldown" : 800,
    },
    {
        #5
        "range" : 150,
        "cooldown" : 500,
    },
]

LANCIER_DATA = [
    {
        #1
        "range" : 36,
        "cooldown" : 0,
        "damage" : 10
    },
    {
        #2
        "range" : 100,
        "cooldown" : 1300,
    },
    {
        #3
        "range" : 120,
        "cooldown" : 1000,
    },
    {
        #4
        "range" : 150,
        "cooldown" : 800,
    },
    {
        #5
        "range" : 150,
        "cooldown" : 500,
    },
]