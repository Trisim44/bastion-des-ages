import pygame as pg
from pygame.math import Vector2
import constants as c
from enemy_data import get_enemy_data
import math
import random


class Enemy(pg.sprite.Sprite):
    def __init__(self, enemy_type, waypoints, images, scale_x, scale_y, death_sheet ,on_death=None):
        pg.sprite.Sprite.__init__(self)
        enemy_stats = get_enemy_data()[enemy_type]
        # Waypoints
        self.waypoints = [(x, y) for x, y in waypoints]
        self.pos = Vector2(self.waypoints[0])
        self.target_waypoint = 1
        self.max_health = enemy_stats["health"]
        self.speed = enemy_stats["speed"]
        self.health = self.max_health

        self.angle = 0
        self.scale_x = scale_x
        self.scale_y = scale_y
        self.alive = True
        self.dying = False
        self.death_frames = self.load_death_animation(death_sheet)
        self.death_index = 0
        self.death_timer = pg.time.get_ticks()
        self.enemy_type = enemy_type
        self.show_health = False
        self.on_death = on_death

        # Animation
        if enemy_type == "strong":  # Mammouth
            frames_per_direction = 10
        else:
            frames_per_direction = 8

        self.animation_list = self.load_directional_animations(images[enemy_type], frames_per_direction)
        self.frame_index = 0
        self.update_time = pg.time.get_ticks()
        self.direction = "down"  # par défaut

        # Image initiale
        self.image = self.animation_list[self.direction][self.frame_index]
        self.rect = self.image.get_rect(center=self.pos)

    def load_directional_animations(self, sprite_sheet, frames_per_direction):
        directions = {"up": [], "down": [], "left": [], "right": []}
        frame_width = sprite_sheet.get_width() // (frames_per_direction * 3)
        frame_height = sprite_sheet.get_height()

        for i in range(frames_per_direction):
            # Haut = frames 0 à N-1
            up = sprite_sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
            directions["up"].append(pg.transform.scale(up, (int(frame_width * self.scale_x), int(frame_height * self.scale_y))))

            # Bas = frames N à 2N-1
            down = sprite_sheet.subsurface(((i + frames_per_direction) * frame_width, 0, frame_width, frame_height))
            directions["down"].append(pg.transform.scale(down, (int(frame_width * self.scale_x), int(frame_height * self.scale_y))))

            # Droite = frames 2N à 3N-1
            right = sprite_sheet.subsurface(((i + 2 * frames_per_direction) * frame_width, 0, frame_width, frame_height))
            scaled_right = pg.transform.scale(right, (int(frame_width * self.scale_x), int(frame_height * self.scale_y)))
            directions["right"].append(scaled_right)

            # Gauche = flip horizontal de droite
            directions["left"].append(pg.transform.flip(scaled_right, True, False))

        return directions

    def update(self, world):
        if self.dying:
            self.play_death_animation(world)
        elif self.alive:
            self.move(world)
            self.play_animation()
            self.check_alive(world)
    def load_death_animation(self, sprite_sheet):
        death_frames = []
        frame_count = 5
        frame_width = sprite_sheet.get_width() // frame_count
        frame_height = sprite_sheet.get_height()
        for i in range(frame_count):
            frame = sprite_sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
            scaled = pg.transform.scale(frame, (int(frame_width * self.scale_x), int(frame_height * self.scale_y)))
            death_frames.append(scaled)
        return death_frames

    def move(self, world):
        if self.target_waypoint < len(self.waypoints):
            self.target = Vector2(self.waypoints[self.target_waypoint])
            self.movement = self.target - self.pos

            dominant_axis_threshold = 1.5  # tu peux ajuster ça

            if abs(self.movement.x) > abs(self.movement.y) * dominant_axis_threshold:
                self.direction = "right" if self.movement.x > 0 else "left"
            elif abs(self.movement.y) > abs(self.movement.x) * dominant_axis_threshold:
                self.direction = "down" if self.movement.y > 0 else "up"
            # Sinon, ne pas changer la direction
        else:
            self.kill()
            world.health -= 1
            world.missed_enemies += 1
            return

        dist = self.movement.length()
        if dist >= (self.speed * world.game_speed):
            self.pos += self.movement.normalize() * (self.speed * world.game_speed)
        else:
            if dist != 0:
                self.pos += self.movement.normalize() * dist
            self.target_waypoint += 1

    def play_animation(self):
        self.image = self.animation_list[self.direction][self.frame_index]
        self.image = pg.transform.rotate(self.image, self.angle)
        self.rect = self.image.get_rect(center=self.pos).inflate(
        int(self.image.get_width() * 0.2),
        int(self.image.get_height() * 0.2)
        )

        # Changer de frame si nécessaire
        if pg.time.get_ticks() - self.update_time > c.ANIMATION_DELAY2:
            self.update_time = pg.time.get_ticks()
            self.frame_index = (self.frame_index + 1) % len(self.animation_list[self.direction])

    def check_alive(self, world):
        if self.alive and self.health < self.max_health:
            self.show_health = True  # Affiche la barre à la première perte de PV

        if self.alive and self.health <= 0:
            self.alive = False
            self.dying = True
            self.on_death()
            self.frame_index = 0
            self.death_timer = pg.time.get_ticks()
            world.killed_enemies += 1
            if self.enemy_type =="strong":
                world.money += 25
            elif self.enemy_type =="weak":
                world.money += 5
            elif self.enemy_type =="medium":
                world.money += 10

    def play_death_animation(self, world):
        if pg.time.get_ticks() - self.death_timer > (c.ANIMATION_DELAY2 / world.game_speed):
            self.death_timer = pg.time.get_ticks()
            self.death_index += 1

            if self.death_index >= len(self.death_frames):
                self.kill()
                return

        self.image = self.death_frames[self.death_index]
        self.rect = self.image.get_rect(center=self.pos)

    def draw_health_bar(self, surface):
        if not self.alive or not self.show_health:
            return


        bar_width = self.rect.width
        bar_height = 5
        health_ratio = self.health / self.max_health
        green_width = int(bar_width * health_ratio)

        x = self.rect.centerx - bar_width // 2
        y = self.rect.top - bar_height - 2

        # Barre rouge (fond)
        pg.draw.rect(surface, (255, 0, 0), (x, y, bar_width, bar_height))
        # Barre verte (vie restante)
        pg.draw.rect(surface, (0, 255, 0), (x, y, green_width, bar_height))