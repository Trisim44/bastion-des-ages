import pygame as pg
import math
import constants as c
from turret_data import COLOSSE_DATA, ARTILLERIE_DATA, LANCIER_DATA
from projectile import Projectile

class Turret(pg.sprite.Sprite):
    def __init__(self, sprite_sheets, x, y, sounds_dict, scale_x, scale_y, turret_type="defense", range_animation_frames=None, emplacement_id=None, rock_sheet=None,rock_explosion_sheet=None, lance_sheet=None, explo_ro=None,vol_rock=None):
        pg.sprite.Sprite.__init__(self)
        self.upgrade_level = 1
        self.range_rotation_angle = 0
        self.turret_type = turret_type
        self.sounds = sounds_dict
        self.scale_x = scale_x
        self.scale_y = scale_y
        self.rock_explosion_sheet = rock_explosion_sheet

        data = self.get_turret_data()
        self.cost = data[0].get("cost", 100)
        self.range = data[self.upgrade_level - 1]["range"] * scale_x
        self.cooldown = data[self.upgrade_level - 1]["cooldown"]
        self.last_shot = pg.time.get_ticks()
        self.sound_effect_explo=explo_ro
        self.selected = False
        self.target = None
        self.range_anim_frames = range_animation_frames or []
        self.range_anim_index = 0
        self.range_anim_timer = pg.time.get_ticks()
        self.range_anim_interval = 80
        self.emplacement_id = emplacement_id
        self.vol_rock=vol_rock
        self.rock_sheet = rock_sheet
        self.lance_sheet = lance_sheet
        self.rock_frames = self.slice_sprite_sheet(self.rock_sheet, 12) if self.rock_sheet else []
        self.x = x
        self.y = y

        self.sprite_sheets = sprite_sheets
        self.animation_list = self.load_images(self.sprite_sheets[self.upgrade_level - 1])
        self.frame_index = 0
        self.update_time = pg.time.get_ticks()

        self.angle = 90
        self.original_image = self.animation_list[self.frame_index]
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y + 28)

        diameter = int(self.range * 2)
        self.range_image = pg.Surface((diameter, diameter), pg.SRCALPHA)
        self.range_image.fill((0, 0, 0, 0))
        pg.draw.ellipse(self.range_image, (255, 100, 100, 100), (0, 0, diameter, diameter))
        self.range_image.set_alpha(100)
        self.range_rect = self.range_image.get_rect()
        self.range_rect.center = self.rect.center

    def slice_sprite_sheet(self, sheet, num_frames):
        frame_width = sheet.get_width() // num_frames
        frame_height = sheet.get_height()

        # Utilise un scale uniforme pour ne pas déformer les sprites
        uniform_scale = min(self.scale_x, self.scale_y)
        target_width = int(frame_width * uniform_scale)
        target_height = int(frame_height * uniform_scale)

        return [
            pg.transform.scale(
                sheet.subsurface((i * frame_width, 0, frame_width, frame_height)),
                (target_width, target_height)
            )
            for i in range(num_frames)
        ]

    def get_turret_data(self):
        if self.turret_type == "defense":
            return COLOSSE_DATA
        elif self.turret_type == "artillerie":
            return ARTILLERIE_DATA
        elif self.turret_type == "lancier":
            return LANCIER_DATA
        else:
            raise ValueError(f"Type de tourelle inconnu : {self.turret_type}")

    def load_images(self, sprite_sheet):
        if self.turret_type == "artillerie":
            steps = c.ANIMATION_STEP_ARTI
        elif self.turret_type == "lancier":
            steps = c.ANIMATION_STEP_LANCIER
        elif self.turret_type == "defense":
            steps = c.ANIMATION_STEPS

        sprite_width = sprite_sheet.get_width() // steps
        sprite_height = sprite_sheet.get_height()
        return [sprite_sheet.subsurface(x * sprite_width, 0, sprite_width, sprite_height) for x in range(steps)]

    def update(self, enemy_group, world):
        # Si une animation est en cours (frame_index > 0) → continue l'animation même sans cible
        if self.frame_index > 0:
            self.play_animation(world, enemy_group)
        elif self.target:
            self.play_animation(world, enemy_group)
        elif pg.time.get_ticks() - self.last_shot > (self.cooldown / world.game_speed):
            self.pick_target(enemy_group)

        # Animation de portée
        if pg.time.get_ticks() - self.range_anim_timer > self.range_anim_interval:
            self.range_anim_index = (self.range_anim_index + 1) % len(self.range_anim_frames)
            self.range_anim_timer = pg.time.get_ticks()

    def pick_target(self, enemy_group):
        in_range_enemies = []

        for enemy in enemy_group:
            if enemy.health > 0:
                dx = enemy.pos.x - self.x
                dy = enemy.pos.y - self.y
                dist = math.hypot(dx, dy)

                if dist <= self.range:
                    # Ajouter l'ennemi avec sa progression
                    in_range_enemies.append((enemy.target_waypoint, enemy))

        if in_range_enemies:
            # Trier par target_waypoint décroissant = progression maximale en premier
            in_range_enemies.sort(key=lambda tup: -tup[0])
            self.target = in_range_enemies[0][1]

            dx = self.target.pos.x - self.x
            dy = self.target.pos.y - self.y
            self.angle = math.degrees(math.atan2(-dy, dx))



    def play_animation(self, world, enemy_group):
        self.original_image = self.animation_list[self.frame_index]
        if pg.time.get_ticks() - self.update_time > (c.ANiMATION_DELAY / world.game_speed):
            self.update_time = pg.time.get_ticks()
            self.frame_index += 1

            data = self.get_turret_data()
            damage = data[self.upgrade_level - 1]["damage"]

            if not hasattr(self, "has_attacked"):
                self.has_attacked = False

            frame_trigger = {
                "lancier": 5,
                "artillerie": 14,
                "defense": 16
            }
            trigger_frame = frame_trigger.get(self.turret_type, len(self.animation_list))

            sound_trigger_frames = {
                "defense": 10,
                "artillerie": 13,
                "lancier": 3
            }
            sound_frame = sound_trigger_frames.get(self.turret_type)
            if self.frame_index == sound_frame:
                if self.turret_type in self.sounds:
                    self.sounds[self.turret_type].play()

            # Mémoriser une position de repli pour tir même si l'ennemi disparaît
            last_target_pos = None

            if not self.has_attacked and self.frame_index == trigger_frame:
                # Si cible existante → mémoriser position
                if self.target:
                    last_target_pos = self.target.pos.xy

                # Vérifier si cible encore dans la portée
                if self.target:
                    dx = self.target.pos.x - self.x
                    dy = self.target.pos.y - self.y
                    dist = math.hypot(dx, dy)
                    if dist > self.range or self.target.health <= 0:
                        self.target = None

                # Tenter de reprendre une nouvelle cible
                if not self.target:
                    self.pick_target(enemy_group)

                # Vérifier si nouvelle cible valide
                if self.target:
                    dx = self.target.pos.x - self.x
                    dy = self.target.pos.y - self.y
                    dist = math.hypot(dx, dy)
                    if dist > self.range or self.target.health <= 0:
                        self.target = None

                # Lancer attaque même sans cible active si on a une ancienne position
                if self.target or last_target_pos:
                    if self.turret_type in ["defense", "artillerie"]:
                        start = (self.x, self.y - 30) if self.turret_type == "defense" else (self.x, self.y)
                        target_pos = self.target.pos.xy if self.target else last_target_pos
                        proj = Projectile(
                            turret_type=self.turret_type,
                            start_pos=start,
                            target_pos=target_pos,
                            damage=damage,
                            radius=60,
                            rock_frames=self.rock_frames,
                            lance_sheet=self.lance_sheet,
                            rock_explosion_sheet=self.rock_explosion_sheet,
                            scale_x=self.scale_x,
                            scale_y=self.scale_y,
                            game_speed=world.game_speed,
                            explosion=self.sound_effect_explo,
                            vol_rock1=self.vol_rock
                        )
                        world.projectile_group.add(proj)
                    else:
                        if self.target:
                            self.target.health -= damage

                self.has_attacked = True

            # Fin de cycle d'animation
            if self.frame_index >= len(self.animation_list):
                self.frame_index = 0
                self.last_shot = pg.time.get_ticks()
                self.target = None
                self.has_attacked = False
                self.original_image = self.animation_list[0]

    def upgrade(self):
        self.upgrade_level += 1
        data = self.get_turret_data()
        self.range = data[self.upgrade_level - 1]["range"]
        self.cooldown = data[self.upgrade_level - 1]["cooldown"]
        self.animation_list = self.load_images(self.sprite_sheets[self.upgrade_level - 1])
        self.original_image = self.animation_list[self.frame_index]

    def draw(self, surface):
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        surface.blit(self.image, self.rect)

    def draw_range(self, surface):
        if self.selected:
            image = self.range_anim_frames[self.range_anim_index]
            rect = image.get_rect()
            rect.center = (self.x, self.y + 28)
            surface.blit(image, rect)

    def get_sell_price(self):
        return int(self.cost * 0.6)
