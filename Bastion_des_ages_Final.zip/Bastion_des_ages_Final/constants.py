"""
voici les constantes du jeu , se sont des valeurs fixe , qui vont etre utilisé tous au long du jeu pour donner des statistiques au ennemies
aux défences mais aussi pour les differentes types de niveaux et de vagues
"""

#Constantes du jeu
SIDE_PANEL = 300
SCREEN_WIDTH = 480
SCREEN_HEIGHT = 270
FPS = 60
scale = 2

difficulté=1
#Constantes de base
HEALTH = 10
MONEY = 300
TOTAL_LEVELS = 10
ACTMENU = 1
ACTRUN = 2
ACTOPTION = 3

#Constantes globales à toutes les défenses
TURRET_LEVELS = 1
UPGRADE_COST = 150
KILL_REWARD = 5
LEVEL_COMPLETE_REWARD = 150

#Constantes des colosses
PRIX_COLOSSE = 250
ANIMATION_STEPS = 19
ANiMATION_DELAY = 50
DAMAGE = 10

#Constantes des artilleries
ANIMATION_STEP_ARTI = 22
ANIMATION_DELAY_ARTI = 30
DAMAGE_ARTILLERIE = 20
PRIX_ARTILLERIE = 175

#Constantes des Legionnaires
ANIMATION_STEP_LANCIER = 12
ANIMATION_DELAY_LANCIER = 30
DAMAGE_LANCIER = 20
PRIX_LANCIER = 100

#Constantes des ennemies
SPAWN_COOLDOWN = 450
ANIMATION_STEPS2 = 8  # car tu as 8 frames
ANIMATION_DELAY2 = 100  # durée en ms entre chaque frame (à ajuster si trop lent/rapide)