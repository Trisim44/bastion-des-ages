# Bastion des Âges - Tower Defense
# ================================
# Fichier principal du jeu

"""
Bienvenue dans le code du jeu "Bastion des Âges"
C'est un jeu dans lequel le joueur va devoir defendre son territoire pendant plusieurs attaques ennemies grace à des défences que le joueur va placer stratégiquement

Le jeu est codé avec la bibliotheque pygame , qui va permettre d'afficher une fenetre de jeu facilement

Nous sommes dans le fichier python "main" qui va permettre de faire marcher la plupart du code sur cette espace et aussi ou nous allons trouvé la boucle de jeu pygame
car un jeu pygame necessite d'etre verifier regulierement pour observer des changements de variables ect...
 """
import time
first_time = True
start_time = time.perf_counter()

########

#//////BASES DU JEU/////

########


# --- IMPORTATIONS DES BIBLIOTHEQUES ---

import pygame as pg
import random
"""Pour jouer avec les fenétres et les images , facilite le rangement de "sprite" et de creation de classes"""

import json
"""Pour lire des fichiers de chemins destinés au ennemies du jeu"""

from enemy import Enemy
"""Fichier ennemie pour facilité le rangement , pour plus de détail , aller sur le fichier"""

import webbrowser
"""POur ouvrir le cahier des charges sur Github"""

"""idem pour pour les suivants"""
from world import World
from turret import Turret
from button import Button
from button import ToggleButton
import constants as c

"""Le reste de ses bibliotheques sont utilisé pour soit extraire des fichiers du pc pour les utilisé , ou bien avoir une fenetre flexible de jeu"""
import os
import sys
import win32gui
import win32con
import ctypes



# --- INITIALISATION ---

pg.init()
pg.mixer.init()
clock = pg.time.Clock()

# --- CREATION FENETRE DE JEU ---

screen = pg.display.set_mode((0,0), pg.FULLSCREEN | pg.DOUBLEBUF)
pg.display.set_caption("Bastion des Âges - Tower Defence")
fake_screen = screen.copy()
webbrowser.open('https://github.com/Trisim44/bastion-des-ages/wiki')

########

#/////VARIABLES/////

########

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS  # dossier temporaire utilisé par PyInstaller
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# --- variables fenetre ----

fullscreen = True
SCREEN_WIDTH, SCREEN_HEIGHT = screen.get_size()
scale_x=(SCREEN_WIDTH / 480)
scale_y=(SCREEN_HEIGHT/ 270)
RATIO = 16 / 9
first_windowed = True

# --- Variable comportement du jeu ---

run = True
game_over = False
game_outcome = 0 # -1 est perdu et 1 est gagné
level_started = False
jeu_en_pause = False
wave_cleared_time = None
show_wave_banner = False
WAVE_BANNER_DURATION = 3500

# --- Variable Boutons ---
placement_angle = 0
last_mouse_x = 0
dernier_bouton_survolé = None

# --- Variable Defenses ---
mamoth_sound= False
placing_turrets = False
selected_turret = None
call_legionnaire = False
call_artillerie = False
call_colosse = False

ghost_turret_sprite = None
ghost_range_frames = []
ghost_range_index = 0
ghost_range_timer = 0

old_health = 10

# --- Variable Ennemies ---
last_enemy_spawn = pg.time.get_ticks()
next_enemy_spawn_delay = int(random.uniform(0.3, 1) * 1000)  # entre 200 et 600 ms

# --- Variable Option Slider ---
volume_slider_pos = 5
volume_temp_musique = 5
volume_temp_defenses = 5
volume_temp_effets = 5
volume_temp = volume_slider_pos
volume_saved = volume_slider_pos
slider_start_x = int(371 * scale_x)
slider_y = int(131 * scale_y)
slider_y_musique = int(156 * scale_y)
slider_y_defenses = int(181 * scale_y)
slider_y_effets = int(206 * scale_y)
slider_spacing = 6 *scale_x

# --- Variable Animations ---
animation_in_progress = False
animation_reverse = False
animation_pause_frame = 0
pause_animation_active = False
pause_menu_active = False
pause_animation_timer = 0
PAUSE_ANIM_INTERVAL = 100
fullscreen = True
placement_anim_index = 0
placement_anim_timer = 0
PLACEMENT_ANIM_INTERVAL = 120  # en millisecondes (ajuste la vitesse ici)
volume_en_pause = 0.1
fade_in_en_cours = False


coeur_anim_index = 0
coeur_anim_timer = pg.time.get_ticks()
coeur_anim_interval = 500  # ms par défaut
coeur_damaged = False
coeur_damage_timer = 0

coin_anim_index = 0
coin_anim_timer = 0
coin_anim_playing = False
coin_anim_interval = 50  # temps entre frames (ms)
money_time=False

intervenance = 1 # 1 = menu , 2 = jeu
in_main_menu = True
action = c.ACTMENU

# --- variables Sons ---
musique_actuelle = None
volume_general = volume_temp / 9
volume_musique = volume_general  # Volume spécifique musique
volume_defenses = volume_general  # Volume spécifique pour les sons de défense
volume_effets = volume_general  # Volume spécifique pour les effets sonores

volume_saved_musique = 5
volume_saved_defenses = 5
volume_saved_effets = 5

slider_drag_general = False
slider_drag_musique = False
slider_drag_defenses = False
slider_drag_effets = False
old_volume_temp = volume_temp
old_volume_temp_musique = volume_temp_musique
old_volume_temp_defenses = volume_temp_defenses
old_volume_temp_effets = volume_temp_effets
musique_en_cours = False


changement_detecté =False


retour_cliqué=False
pleine_écran_cliqué=False


def update_screen_scale():
    global SCREEN_WIDTH, SCREEN_HEIGHT, scale_x, scale_y
    SCREEN_WIDTH, SCREEN_HEIGHT = screen.get_size()
    scale_x = SCREEN_WIDTH / 480
    scale_y = SCREEN_HEIGHT / 270

# --- Variables Coordonnés Carte ---
coordonnes_map = {
    "Prehistoire": [
    (int(84 * scale_x) , int(16 * scale_y), 1),
    (int(102 * scale_x), int(38 * scale_y), 2),
    (int(30 * scale_x), int(48 * scale_y), 3),
    (int(145 * scale_x), int(43 * scale_y), 4),
    (int(191 * scale_x), int(40 * scale_y), 5),
    (int(228 * scale_x) , int(1 * scale_y), 6),
    (int(274 * scale_x), int(1 * scale_y), 7),
    (int(320 * scale_x), int(1 * scale_y) , 8),
    (int(347 * scale_x), int(37 * scale_y) , 9),
    (int(52 * scale_x), int(78 * scale_y) , 10),
    (int(92 * scale_x), int(96 * scale_y) , 11),
    (int(140 * scale_x) , int(96 * scale_y), 12),
    (int(189 * scale_x) , int(96 * scale_y), 13),
    (int(233 * scale_x) , int(82 * scale_y) , 14),
    (int(242 * scale_x) , int(109 * scale_y) , 15),
    (int(270 * scale_x), int(50 * scale_y) , 16),
    (int(280 * scale_x) , int(88 * scale_y) , 17),
    (int(343 * scale_x) , int(74 * scale_y) , 18),
    (int(342 * scale_x) , int(109 * scale_y), 19),
    (int(326 * scale_x), int(146 * scale_y) , 20),
    (int(287 * scale_x) , int(161 * scale_y) , 21),
    (int(244 * scale_x) , int(163 * scale_y) , 22),
    (int(203 * scale_x) , int(163 * scale_y), 23),
    (int(163 * scale_x) , int(155 * scale_y)-16, 24),
    (int(110 * scale_x), int(148 * scale_y) , 25),
    (int(101 * scale_x) , int(165 * scale_y), 26),
    (int(147 * scale_x) , int(166 * scale_y) , 27),
    (int(45 * scale_x) , int(123 * scale_y) , 28),
    (int(32 * scale_x) , int(166* scale_y) , 29),
    (int(50 * scale_x) , int(209 * scale_y) , 30),
    (int(92 * scale_x), int(222 * scale_y) , 31),
    (int(138 * scale_x) , int(223 * scale_y), 32),
    (int(182 * scale_x) , int(223 * scale_y) , 33),
    (int(223 * scale_x) , int(219 * scale_y) , 34),
    (int(293 * scale_x) , int(200 * scale_y) , 35)],
    "Antiquité": [(50, 550), (200, 450), (400, 350), (600, 250), (800, 150)],
    "Moyen-Age": [(120, 480), (320, 380), (520, 280), (720, 180), (820, 80)]
    }




########

#/////IMPORTATIONS IMAGES DU JEU/////

########
rock_sheet = pg.image.load(resource_path("assets/turret/colosse/caillou.png")).convert_alpha()
lance_sheet = pg.image.load(resource_path("assets/turret/artillerie/lance_anim.png")).convert_alpha()
rock_explosion_sheet = pg.image.load(resource_path('assets/turret/colosse/explosion_caillou.png')).convert_alpha()
coeur_sheet = pg.image.load("assets/gui/coeur.png").convert_alpha()
coeur_frames = []
coeur_frame_width = coeur_sheet.get_width() // 4  # 4 frames
coeur_frame_height = coeur_sheet.get_height()

for i in range(4):
    frame = coeur_sheet.subsurface((i * coeur_frame_width, 0, coeur_frame_width, coeur_frame_height))
    frame = pg.transform.scale(frame, (int(coeur_frame_width * scale_x), int(coeur_frame_height * scale_y)))
    coeur_frames.append(frame)
coin_sheet = pg.image.load(resource_path("assets/gui/piece.png")).convert_alpha()
coin_frames = []
frame_width = coin_sheet.get_width() // 8
frame_height = coin_sheet.get_height()

for i in range(8):
    frame = coin_sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
    frame = pg.transform.scale(frame, (int(frame_width * scale_x), int(frame_height * scale_y)))
    coin_frames.append(frame)

def load_range_animation_frames(sheet, frame_count, scale_x=1.0, scale_y=1.0):
    frames_range = []
    frame_width = sheet.get_width() // frame_count
    frame_height = sheet.get_height()
    for i in range(frame_count):
        frame = sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
        frame = pg.transform.scale(frame, (int(frame_width * scale_x), int(frame_height * scale_y)))
        frames_range.append(frame)
    return frames_range

range_sheet_defense = pg.image.load(resource_path('assets/turret/colosse/range_colosse.png')).convert_alpha()
range_sheet_artillerie = pg.image.load(resource_path('assets/turret/artillerie/range_artillerie.png')).convert_alpha()
range_sheet_lancier = pg.image.load(resource_path('assets/turret/legionnaire/range_legionnaire.png')).convert_alpha()

range_animations_by_type = {
    "defense": load_range_animation_frames(range_sheet_defense, 6, scale_x, scale_y),
    "artillerie": load_range_animation_frames(range_sheet_artillerie, 6, scale_x, scale_y),
    "lancier": load_range_animation_frames(range_sheet_lancier, 6, scale_x, scale_y),
}





stats_sheet = pg.image.load(resource_path("assets/gui/stats.png")).convert_alpha()
stats_frames = []
frame_width = stats_sheet.get_width() // 3
frame_height = stats_sheet.get_height()

for i in range(3):
    frame = stats_sheet.subsurface((i * frame_width, 0, frame_width, frame_height))
    frame = pg.transform.scale(frame, (int(frame_width * scale_x), int(frame_height * scale_y)))
    stats_frames.append(frame)

# --- Carte ---
map_image = pg.transform.scale(pg.image.load(resource_path('levels/map_teis.png')).convert_alpha(),(int(384 * scale_x), int(270 * scale_y)))

# --- Ennemies ---

enemy_images = {
    "weak": pg.image.load(resource_path('assets/enemy/tigre_a_dent_de_sabre.png')).convert_alpha(),
    "medium": pg.image.load(resource_path('assets/enemy/oiseau_prehistorique.png')).convert_alpha(),
    "strong": pg.image.load(resource_path('assets/enemy/mammouth.png')).convert_alpha(),
    "elite": pg.image.load(resource_path('assets/enemy/mammouth.png')).convert_alpha()
}

# --- Défences ---
#Variable global
selected_turret_type = "defense"
# Colosse
turret_spritesheets = []
for x in range(1, c.TURRET_LEVELS + 1):
    turret_sheet = pg.transform.scale(pg.image.load(resource_path('assets/turret/colosse/colosse.png')).convert_alpha(),(int(608*scale_x), int(32*scale_y)))
    turret_spritesheets.append(turret_sheet)
cursor_turret = pg.transform.scale(pg.image.load(resource_path('assets/turret/colosse/cursor_colosse.png')).convert_alpha(), (int(32*scale_x), int(32*scale_y)))

#Artillerie
turret_spritesheets_artillerie = []
for x in range(1, c.TURRET_LEVELS + 1):
    turret_sheet_artillerie = pg.transform.scale(pg.image.load(resource_path('assets/turret/artillerie/artillerie.png')).convert_alpha(),(int(704*scale_x), int(32*scale_y)))
    turret_spritesheets_artillerie.append(turret_sheet_artillerie)
cursor_turret_artillerie = pg.transform.scale(pg.image.load(resource_path('assets/turret/artillerie/cursor_artillerie.png')).convert_alpha(), (int(32*scale_x), int(32*scale_y)))

#Legionnaire
turret_spritesheets_lancier = []
for x in range(1, c.TURRET_LEVELS + 1):
    turret_sheet_legionnaire = pg.transform.scale(pg.image.load(resource_path('assets/turret/legionnaire/legionnaire.png')).convert_alpha(),(int(384*scale_x), int(32*scale_y)))
    turret_spritesheets_lancier.append(turret_sheet_legionnaire)
cursor_turret_lancier = pg.transform.scale(pg.image.load(resource_path('assets/turret/legionnaire/curseur_legionnaire.png')).convert_alpha(),(int(32*scale_x), int(32*scale_y)))

# --- Images Boutons ---

#Jeu
bouton_colosse = pg.transform.scale(pg.image.load(resource_path('assets/buttons/colosse_bouton.png')).convert_alpha(),(int(240*scale_x),int(20*scale_y)))
bouton_legionnaire = pg.transform.scale(pg.image.load(resource_path('assets/buttons/legionnaire_bouton.png')).convert_alpha(),(int(246*scale_x),int(19*scale_y)))
bouton_artillerie = pg.transform.scale(pg.image.load(resource_path('assets/buttons/artillerie_bouton.png')).convert_alpha(),(int(243*scale_x),int(19*scale_y)))
bouton_annulé = pg.transform.scale(pg.image.load(resource_path('assets/buttons/bouton_annulé.png')).convert_alpha(),(int(102*scale_x),int(14*scale_y)))
bouton_amelioré = pg.transform.scale(pg.image.load(resource_path('assets/buttons/Amelioré_boutton.png')).convert_alpha(),(int(164*scale_x),int(19*scale_y)))
spritesheet_vendre = pg.transform.scale(
    pg.image.load(resource_path('assets/buttons/vendre_bouton.png')).convert_alpha(),
    (int(94 * scale_x), int(15 * scale_y))  # largeur x2 par rapport à avant
)

# Menu
jouer_button = Button(int(189*scale_x), int(144*scale_y), pg.transform.scale(pg.image.load(resource_path("assets/gui/bouton_jouer.png")).convert_alpha(), (int(91*scale_x), int(34*scale_y))), True)
options_button = Button(int(189*scale_x), int(186*scale_y), pg.transform.scale(pg.image.load(resource_path("assets/gui/bouton_option.png")).convert_alpha(), (int(91*scale_x), int(34*scale_y))), True)
quitter_button = Button(int(189*scale_x), int(228*scale_y), pg.transform.scale(pg.image.load(resource_path("assets/gui/bouton_quitter.png")).convert_alpha(), (int(91*scale_x),int(34*scale_y))), True)

#gamemover
# Boutons de fin

bouton_rejouer = Button(int(189 * scale_x), int(150 * scale_y), pg.transform.scale(pg.image.load(resource_path("assets/gui/bouton_jouer.png")).convert_alpha(), (int(91 * scale_x), int(34 * scale_y))), True)
bouton_quitter_fin = Button(int(189 * scale_x), int(200 * scale_y), pg.transform.scale(pg.image.load(resource_path("assets/gui/bouton_quitter.png")).convert_alpha(), (int(91 * scale_x), int(34 * scale_y))), True)

#pause
Bouton_retour_appuyer = pg.transform.scale(pg.image.load(resource_path('assets/buttons/bouton_retour_option.png')).convert_alpha(),(int(88*scale_x),int(34*scale_y)))
Bouton_annulé_options = pg.transform.scale(pg.image.load(resource_path('assets/buttons/annulé_options.png')).convert_alpha(),(int(44*scale_x),int(17*scale_y)))
Bouton_appliquer_options = pg.transform.scale(pg.image.load(resource_path('assets/buttons/boutton_appliquer.png')).convert_alpha(),(int(75*scale_x),int(29*scale_y)))

#options
levier_son = pg.transform.scale(pg.image.load(resource_path('assets/buttons/option rouge.png')).convert_alpha(),(int(10*scale_x),int(10*scale_y)))
option_in_game_button = pg.image.load(resource_path("assets/gui/bouton_option.png")).convert_alpha()

death_sheet = pg.image.load(resource_path('assets/enemy/mort.png')).convert_alpha()

# --- Interface ---

menu_fond= pg.transform.scale(pg.image.load(resource_path('assets/gui/menu.png')).convert_alpha(),(int(480 * scale_x), int(270 * scale_y)))
titre = pg.transform.scale(pg.image.load(resource_path('assets/gui/Titre.png')).convert_alpha(),(int(168 * scale_x), int(122 * scale_y)))
map_GUI = pg.image.load(resource_path('assets/gui/Interface_prehistoire.png')).convert_alpha()
bouton_option = pg.transform.scale(pg.image.load(resource_path('assets/gui/pause_boutton.png')).convert_alpha(), (int(21*scale_x), int(21*scale_y)))
zone_pause = pg.transform.scale(pg.image.load(resource_path('assets/gui/pause_zone.png')).convert_alpha(), (int(3852*scale_x), int(238*scale_y)))
zone_options = pg.transform.scale(pg.image.load(resource_path('assets/gui/pause_option.png')).convert_alpha(), (int(480*scale_x), int(270*scale_y)))
banniere_vague = pg.transform.scale(pg.image.load(resource_path('assets/gui/banniere vague.png')).convert_alpha(),(int(480*scale_x),int(49*scale_y)))

pause_frames = []
pause_frame_width = zone_pause.get_width() // 18
pause_frame_height = zone_pause.get_height()

for i in range(18):
    frame = zone_pause.subsurface(pg.Rect(i * pause_frame_width, 0, pause_frame_width, pause_frame_height))
    pause_frames.append(frame)





########

#////IMPORTATION AUTRES/////

########

# ---Chargement des sons ---

#musique
pg.mixer.music.load(resource_path('assets/audio/musique/musique_jeu_prehistoire.ogg'))
musique_menu = pg.mixer.Sound(resource_path('assets/audio/musique/musique_menu.ogg'))
musique_option = pg.mixer.Sound(resource_path('assets/audio/musique/musique_option.ogg'))
foret = pg.mixer.Sound(resource_path('assets/audio/musique/musique_ambiance_jeu.ogg'))
musique_pause= pg.mixer.Sound(resource_path('assets/audio/musique/musique_pause.ogg'))
musique_fin= pg.mixer.Sound(resource_path('assets/audio/musique/musique_fin.ogg'))

#defense
shot_arrow = pg.mixer.Sound(resource_path('assets/audio/defenses/war_cry_artillerie.ogg'))
shot_fx = pg.mixer.Sound(resource_path('assets/audio/defenses/war_cry_colosse.ogg'))
shot_os = pg.mixer.Sound(resource_path('assets/audio/defenses/war_cry_legionnaire.ogg'))
hit_artillerie=pg.mixer.Sound(resource_path('assets/audio/defenses/touche_artillerie.ogg'))
hit_legionnaire=pg.mixer.Sound(resource_path('assets/audio/defenses/touche_legionnaire.ogg'))
shot_os.set_volume(0.3)

#effets
trompette_de_guerre = pg.mixer.Sound(resource_path('assets/audio/effets/corne_de_brume.ogg'))
refuse= pg.mixer.Sound(resource_path('assets/audio/effets/impossible.ogg'))
rock= pg.mixer.Sound(resource_path('assets/audio/effets/pause_bouton_rock.ogg'))
wood = pg.mixer.Sound(resource_path('assets/audio/effets/bouton_menu_select_wood.ogg'))
money = pg.mixer.Sound(resource_path('assets/audio/effets/son_argent_defense_acheter.ogg'))
click = pg.mixer.Sound(resource_path('assets/audio/effets/click_bouton_menu.ogg'))
engrenage = pg.mixer.Sound(resource_path('assets/audio/effets/engrenage_pause.ogg'))
pause_amb= pg.mixer.Sound(resource_path('assets/audio/effets/ouverture_pause.ogg'))
ferm_pause= pg.mixer.Sound(resource_path('assets/audio/effets/fermeture_pause.ogg'))
anul_appliq= pg.mixer.Sound(resource_path('assets/audio/effets/bouton_pause_annule_applique.ogg'))
dec_son= pg.mixer.Sound(resource_path('assets/audio/effets/option_son_niveau.ogg'))
bouton_metal= pg.mixer.Sound(resource_path('assets/audio/effets/metal_bouton.ogg'))
vendre_kashing= pg.mixer.Sound(resource_path('assets/audio/effets/vendre_son.ogg'))
mort_son= pg.mixer.Sound(resource_path('assets/audio/effets/poof_mort_ennemi.ogg'))
money_recevoir=pg.mixer.Sound(resource_path('assets/audio/effets/recevoir_argent.ogg'))
defense_click=pg.mixer.Sound(resource_path('assets/audio/effets/bouton_defense_click.ogg'))
defense_annule_click=pg.mixer.Sound(resource_path('assets/audio/effets/annule_defense.ogg'))
die=pg.mixer.Sound(resource_path('assets/audio/effets/die.ogg'))
explo_rocki=pg.mixer.Sound(resource_path('assets/audio/effets/caillou_detruit.ogg'))
airborn=pg.mixer.Sound(resource_path('assets/audio/effets/airborn.ogg'))
mamouth=pg.mixer.Sound(resource_path('assets/audio/effets/mammoth.ogg'))


def appliquer_volumes():
    #appliqué son musique
    pg.mixer.music.set_volume(volume_musique*volume_general)
    musique_menu.set_volume(volume_musique*volume_general)
    musique_option.set_volume(volume_musique*volume_general)
    musique_pause.set_volume(volume_musique*volume_general)
    foret.set_volume((volume_musique*0.05)*volume_general)


    #appliqué son defenses
    shot_arrow.set_volume((volume_defenses*1.4)*volume_general)
    shot_fx.set_volume((volume_defenses*0.6)*volume_general)
    shot_os.set_volume((volume_defenses*0.8)*volume_general)
    hit_legionnaire.set_volume(volume_defenses*volume_general)
    hit_artillerie.set_volume(volume_defenses*volume_general)

    #appliqué son effets
    trompette_de_guerre.set_volume(volume_effets*volume_general)
    refuse.set_volume(volume_effets*volume_general)
    rock.set_volume(volume_effets*volume_general)
    wood.set_volume(volume_effets*volume_general)
    foret.set_volume(volume_effets*volume_general)
    money.set_volume(volume_effets*volume_general)
    click.set_volume(volume_effets*volume_general)
    engrenage.set_volume(volume_effets*volume_general)
    pause_amb.set_volume(volume_effets*volume_general)
    ferm_pause.set_volume(volume_effets*volume_general)
    anul_appliq.set_volume(volume_effets*volume_general)
    dec_son.set_volume(volume_effets*volume_general)
    bouton_metal.set_volume(volume_effets*volume_general)
    vendre_kashing.set_volume(volume_effets*volume_general)
    mort_son.set_volume((volume_effets*0.3)*volume_general)
    money_recevoir.set_volume(volume_effets*volume_general)
    defense_annule_click.set_volume(volume_effets*volume_general)
    defense_click.set_volume(volume_effets*volume_general)
    die.set_volume(volume_effets*volume_general)
    explo_rocki.set_volume((volume_effets*0.5)*volume_general)
    airborn.set_volume((volume_effets*0.3)*volume_general)
    mamouth.set_volume((volume_effets*0.8)*volume_general)



def play_enemy_death_sound():
    mort_son.play()

def explo_rock():
    explo_rocki.play()
def vol_rock():
    airborn.play()



# Chargement des fichier json
with open(resource_path('levels/prehistoire3.tmj')) as file:
  world_data = json.load(file)

# Charges des polices de textes du jeu
text_font = pg.font.Font(resource_path("minecraft_font.ttf"), (int(8*scale_y)))
game_font = pg.font.Font(resource_path("minecraft_font.ttf"), (int(32 * scale_y)))
large_font = pg.font.SysFont(resource_path("minecraft_font.ttf"), (int(12*scale_y)))

# --- créer interface ---
world = World(world_data, map_image)
world.process_data(scale_x, scale_y)
world.process_enemies()

#création des groupes
liste_des_defences_deja_utilisé = []
turret_group = pg.sprite.Group()
enemy_group = pg.sprite.Group()
world.projectile_group = pg.sprite.Group()


#créations des boutons
colosse_button = ToggleButton(int((375+16)*scale_x), int(110*scale_y), bouton_colosse, 3, True)
artillerie_button = ToggleButton(int((375+15)*scale_x), int(88*scale_y), bouton_artillerie, 3, True)
legionnaire_button = ToggleButton(int((375+15)*scale_x), int(67*scale_y), bouton_legionnaire, 3, True)
cancel_button = ToggleButton(int((375+28)*scale_x), int(130*scale_y), bouton_annulé, 2, True)
upgrade_button = Button(int(490*scale_x),180, bouton_amelioré, True)
Bouton_Commencer = pg.Rect(391*scale_x,35*scale_y,82*scale_x,21*scale_y)
bouton_vendre = ToggleButton(int(395 * scale_x), int(236 * scale_y), spritesheet_vendre, num_flags=2, single_click=False)
pause_button = Button(5, 5, bouton_option, True)
pause_menu_button = Button(300, 310, option_in_game_button, True)
Bouton_retour = pg.Rect(196*scale_x,47*scale_y,88*scale_x,34*scale_y)
bouton_pleine_ecran= pg.Rect(61*scale_x,127*scale_y,97*scale_x,27*scale_y)
bouton_fenetre= pg.Rect(61*scale_x,180*scale_y,97*scale_x,27*scale_y)
bouton_retour_pause= pg.Rect(186*scale_x,94*scale_y,102*scale_x,33*scale_y)
bouton_options_pause= pg.Rect(183*scale_x,133*scale_y,104*scale_x,36*scale_y)
bouton_menu_pause= pg.Rect(184*scale_x,176*scale_y,102*scale_x,36*scale_y)
appliquer_rect = pg.Rect(202*scale_x,127*scale_y,75*scale_x,29*scale_y)
annuler_rect =pg.Rect(218*scale_x,160*scale_y,44*scale_x,17*scale_y)

#######

#/////FONCTIONS/////

#######

# --- fonction de fenetre ---
class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]
def wndProc(oldWndProc, draw_callback, hWnd, message, wParam, lParam):
    if message == win32con.WM_SIZING:
        rect_ptr = ctypes.cast(lParam, ctypes.POINTER(RECT))
        rect = rect_ptr.contents

        width = rect.right - rect.left
        new_height = int(width / RATIO)

        # Keep top constant, adjust bottom
        rect.bottom = rect.top + new_height

        return 1  # Indique qu'on gère ce message

    elif message == win32con.WM_SIZE:
        draw_callback()
        win32gui.RedrawWindow(hWnd, None, None, win32con.RDW_INVALIDATE | win32con.RDW_ERASE)

    return win32gui.CallWindowProc(oldWndProc, hWnd, message, wParam, lParam)

# --- fonction pour afficher les textes ---
def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    fake_screen.blit(img, (x, y))

def display_data():
    #Montre les informations comme la vie et l'argent
    draw_text(str(world.health), text_font, (255, 255, 255), int(447*scale_x), int(11*scale_y))
    draw_text(str(world.money), text_font, (255, 255, 255), int(394*scale_x), int(11*scale_y))

# --- Création des défences ---

def create_turret(mouse_pos,turret_type):
    global placing_turrets

    # Chercher sur quel emplacement on a cliqué
    for x, y, id in coordonnes_map["Prehistoire"]:
        rect = pg.Rect(x, y, placement_tourelle_frames[0].get_width(), placement_tourelle_frames[0].get_height())
        if rect.collidepoint(mouse_pos):
            # Vérifier si l'emplacement est libre
            if id not in liste_des_defences_deja_utilisé:
                # Créer une nouvelle tourelle
                frame_w = placement_tourelle_frames[0].get_width()
                frame_h = placement_tourelle_frames[0].get_height()

                center_x = x + frame_w // 2
                center_y = y + frame_h // 2

                # Choisir le bon type de tourelle
                if turret_type == "defense":
                    sprite_sheets = turret_spritesheets
                    sound = shot_fx
                    prix = c.PRIX_COLOSSE
                    call_colosse  = True
                elif turret_type == "artillerie":
                    sprite_sheets = turret_spritesheets_artillerie
                    sound = shot_os
                    prix = c.PRIX_ARTILLERIE
                    call_artillerie  = True
                elif turret_type == "lancier":
                    sprite_sheets = turret_spritesheets_lancier
                    sound = shot_arrow
                    prix = c.PRIX_LANCIER
                    call_legionnaire = True


                else:
                    return

                if world.money >= prix:
                    new_turret = Turret(
                        sprite_sheets, center_x, center_y,
                        {
                            "defense": shot_fx,
                            "artillerie": shot_arrow,
                            "lancier": shot_os,
                        },
                        scale_x, scale_y,
                        turret_type=turret_type,
                        range_animation_frames=range_animations_by_type[turret_type],
                        emplacement_id=id,rock_sheet=rock_sheet,rock_explosion_sheet=rock_explosion_sheet,
                        lance_sheet=lance_sheet,explo_ro=explo_rock,vol_rock=vol_rock
                    )

                    turret_group.add(new_turret)
                    liste_des_defences_deja_utilisé.append(id)
                    world.money -= prix
                    money.play()
                    placing_turrets = False
                    call_artillerie= False
                    call_legionnaire= False
                    call_colosse = False
            else:
                print("Emplacement déjà utilisé !")
            break
def jouer_musique(sound):
    global musique_actuelle

    if musique_actuelle != sound:
        pg.mixer.stop()
        sound.play(loops=-1, fade_ms=500)
        musique_actuelle = sound


def select_turret(mouse_pos):
    mouse_x, mouse_y = mouse_pos
    for turret in turret_group:
        rect = turret.image.get_rect(center=(turret.x, turret.y))
        if rect.collidepoint(mouse_pos):
            return turret
    return None

def clear_selection():
    for turret in turret_group:
        turret.selected = False

def draw_callback():
    screen.blit(pg.transform.scale(fake_screen, screen.get_rect().size), (0, 0))
    pg.display.flip()

def fade_in(draw_callback, target_surface, duration=1000):
    """Fondu noir transparent vers l'écran actif.

    - draw_callback : une fonction qui redessine le contenu (fond + boutons, etc.)
    - target_surface : typiquement `screen` ou `fake_screen`
    """
    fade = pg.Surface(target_surface.get_size())
    fade.fill((0, 0, 0))
    clock = pg.time.Clock()
    start_time = pg.time.get_ticks()

    running = True
    while running:
        elapsed = pg.time.get_ticks() - start_time
        alpha = max(0, 255 - int((255 * elapsed) / duration))
        if alpha <= 0:
            running = False

        # Redessiner le contenu
        draw_callback()

        # Appliquer le fade
        fade.set_alpha(alpha)
        target_surface.blit(fade, (0, 0))
        pg.display.flip()
        clock.tick(60)


def fade_out(draw_callback, target_surface, duration=1000):

    fade = pg.Surface(target_surface.get_size())
    fade.fill((0, 0, 0))
    clock = pg.time.Clock()
    start_time = pg.time.get_ticks()

    running = True
    while running:
        elapsed = pg.time.get_ticks() - start_time
        alpha = min(255, int((255 * elapsed) / duration))
        if alpha >= 255:
            running = False

        # Redessiner les éléments actuels
        draw_callback()

        # Appliquer le fondu
        fade.set_alpha(alpha)
        target_surface.blit(fade, (0, 0))
        pg.display.flip()
        clock.tick(60)


def draw_menu():
    global start_time
    global first_time
    global dernier_bouton_survolé

    if first_time == True:
        end_time = time.perf_counter()

        elapsed_time = end_time - start_time

        print(f"Elapsed time: {elapsed_time:.1f} seconds")
        first_time = False

    souris_survol_bouton = False
    fake_screen.blit(menu_fond, (0, 0))
    fake_screen.blit(titre,(int(150*scale_x),int(8*scale_y)))
    mouse_pos = pg.mouse.get_pos()

    for btn in [jouer_button, options_button, quitter_button]:
        if btn.rect.collidepoint(mouse_pos):
            # Agrandir l’image temporairement
            if btn.rect.collidepoint(mouse_pos):
                souris_survol_bouton = True
                if dernier_bouton_survolé != btn:
                    wood.play()
                    dernier_bouton_survolé = btn
            scale_factor = 1.05
            new_width = int(btn.image.get_width() * scale_factor)
            new_height = int(btn.image.get_height() * scale_factor)
            scaled_image = pg.transform.scale(btn.image, (new_width, new_height))
            center = btn.rect.center
            new_rect = scaled_image.get_rect(center=center)
            fake_screen.blit(scaled_image, new_rect)
        else:
            btn.draw(fake_screen)

    if not souris_survol_bouton:
        dernier_bouton_survolé = None

    #credits
    credit_text = text_font.render(" by  Simon ,  Ewenn  and  Teis ", True, (255, 255, 255))
    credit_rect = credit_text.get_rect()
    credit_rect.bottomright = (SCREEN_WIDTH, SCREEN_HEIGHT)
    fake_screen.blit(credit_text, credit_rect)
    #rafraichissement de l'image
    screen.blit(pg.transform.scale(fake_screen, screen.get_rect().size), (0, 0))

def draw_options():

    fake_screen.blit(zone_options, (0, 0))
    if retour_cliqué==True :
        fake_screen.blit(Bouton_retour_appuyer,(196*scale_x,47*scale_y))
    if pleine_écran_cliqué==True :
        fake_screen.blit(Bouton_retour_appuyer,(196*scale_x,47*scale_y))

    if not changement_detecté:
        # aucun changement
        fake_screen.blit(Bouton_appliquer_options, (202*scale_x, 127*scale_y))
        fake_screen.blit(Bouton_annulé_options, (218*scale_x, 160*scale_y))



    cursor_x_musique = slider_start_x + volume_temp_musique * slider_spacing
    cursor_x_defenses = slider_start_x + volume_temp_defenses * slider_spacing
    cursor_x_effets = slider_start_x + volume_temp_effets * slider_spacing
    cursor_x = slider_start_x + volume_temp * slider_spacing


    # affichage des curseurs
    fake_screen.blit(levier_son, levier_son.get_rect(center=(cursor_x_musique, slider_y_musique)))
    fake_screen.blit(levier_son, levier_son.get_rect(center=(cursor_x_defenses, slider_y_defenses)))
    fake_screen.blit(levier_son, levier_son.get_rect(center=(cursor_x_effets, slider_y_effets)))
    fake_screen.blit(levier_son, levier_son.get_rect(center=(cursor_x, slider_y)))
    screen.blit(pg.transform.scale(fake_screen, screen.get_rect().size), (0, 0))


def draw_run():
    global animation_in_progress
    global jeu_en_pause
    global map_gui_frame_index
    global pause_animation_active
    global animation_pause_frame
    global pause_menu_active
    global pause_animation_timer
    global show_wave_banner
    global WAVE_BANNER_DURATION
    global game_outcome
    global placing_turrets
    global prix
    global coeur_damaged
    global coeur_damage_timer
    global coeur_anim_timer
    global coeur_anim_index
    global coeur_anim_interval
    global old_health
    global old_money
    global coin_anim_index
    global coin_anim_timer
    global money_time
    global coin_anim_playing
    frame_index = 0



    world.draw(fake_screen)
    fake_screen.blit(map_image,(0,0))
    for turret in turret_group:
        turret.draw_range(fake_screen)
    enemy_group.draw(fake_screen)
    for turret in turret_group:
        turret.draw(fake_screen)

    for enemy in enemy_group:
        enemy.draw_health_bar(fake_screen)
    for projectile in world.projectile_group:
        world.projectile_group.draw(fake_screen)
    if animation_in_progress:
        fake_screen.blit(map_gui_frames[map_gui_frame_index], (int(375*scale_x), 0))
        if pg.time.get_ticks() % 100 < 20:
            if animation_reverse:
                map_gui_frame_index -= 1
                if map_gui_frame_index <= 0:
                    map_gui_frame_index = 0
                    animation_in_progress = False  # Fin de l'animation inverse
            else:
                map_gui_frame_index += 1
                if map_gui_frame_index >= 8:
                    map_gui_frame_index = 8
                    animation_in_progress = False  # Fin de l'animation normale
    else:
        fake_screen.blit(map_gui_frames[min(map_gui_frame_index, 17)], (int(375*scale_x), 0))

    if world.game_speed == 2:
        fake_screen.blit(map_gui_frames[min(map_gui_frame_index+1, 17)], (int(375*scale_x), 0))
        display_data()
    if selected_turret:
        if selected_turret.turret_type == "lancier":
            frame_index = 0
        elif selected_turret.turret_type == "defense":
            frame_index = 1
        elif selected_turret.turret_type == "artillerie":
            frame_index = 2


        fake_screen.blit(stats_frames[frame_index], (int(396 * scale_x), int(176 * scale_y)))


    if placing_turrets == True :
        cancel_button.current_state = 1
        if call_colosse==True:
            colosse_button.current_state = 2
        if call_legionnaire==True:
            legionnaire_button.current_state = 2
        if call_artillerie==True:
            artillerie_button.current_state = 2

    else:
        cancel_button.current_state = 0
        if world.money >= 250 :
            colosse_button.current_state = 1
        else:
            colosse_button.current_state = 0
        if world.money >= 175 :

            artillerie_button.current_state = 1
        else:
            artillerie_button.current_state = 0
        if world.money >= 100 :
            legionnaire_button.current_state = 1
        else:
            legionnaire_button.current_state = 0
    # --- Affichage de la portée animée autour du curseur ---



    colosse_button.draw(fake_screen)
    artillerie_button.draw(fake_screen)
    legionnaire_button.draw(fake_screen)
    cancel_button.draw(fake_screen)
    # Affichage du bouton vendre selon si une tourelle est sélectionnée
    if selected_turret:
        bouton_vendre.current_state = 1  # allumé
    else:
        bouton_vendre.current_state = 0  # éteint

    bouton_vendre.draw(fake_screen)

    if placing_turrets == True :
        if ghost_range_frames:
            mouse_x, mouse_y = pg.mouse.get_pos()

            # Affiche la portée animée
            global ghost_range_index, ghost_range_timer
            if pg.time.get_ticks() - ghost_range_timer > 80:
                ghost_range_index = (ghost_range_index + 1) % len(ghost_range_frames)
                ghost_range_timer = pg.time.get_ticks()

            ghost_range_image = ghost_range_frames[ghost_range_index].copy()
            ghost_range_image.set_alpha(128)
            range_rect = ghost_range_image.get_rect(center=(mouse_x, mouse_y + 28))
            fake_screen.blit(ghost_range_image, range_rect)

        #Montre la defence cliqué sur la souris
        for x, y, id in coordonnes_map["Prehistoire"]:
            if id not in liste_des_defences_deja_utilisé:
                fake_screen.blit(placement_tourelle_frames[placement_anim_index], (x, y))
            # Déterminer le sprite à afficher sous la souris
        if selected_turret_type == "defense":
            cursor_img = cursor_turret
        elif selected_turret_type == "artillerie":
            cursor_img = cursor_turret_artillerie
        elif selected_turret_type == "lancier":
            cursor_img = cursor_turret_lancier
        else:
            cursor_img = cursor_turret

        cursor_pos = pg.mouse.get_pos()
        global placement_angle, last_mouse_x

        # Vitesse horizontale absolue
        delta_x = cursor_pos[0] - last_mouse_x
        speed = abs(delta_x)

        # Mapper vitesse → angle (ex: 0px → 0°, 40px+ → max 20°)
        max_speed = 40
        max_angle = 20
        angle = min(max_angle, int((speed / max_speed) * max_angle))

        # Orientation selon direction
        if delta_x > 0:
            placement_angle = -angle
        elif delta_x < 0:
            placement_angle = angle
        else:
            # Revenir doucement à 0
            if placement_angle > 0:
                placement_angle -= 1
            elif placement_angle < 0:
                placement_angle += 1

        last_mouse_x = cursor_pos[0]

        rotated_cursor = pg.transform.rotate(cursor_img, placement_angle)
        rotated_rect = rotated_cursor.get_rect(center=cursor_pos)
        fake_screen.blit(rotated_cursor, rotated_rect)
    display_data()
    current_time = pg.time.get_ticks()
    if not jeu_en_pause :
        if level_started and map_gui_frame_index>= 8:


            # Détection gain d’argent
            if money_time:
                coin_anim_playing = True
                coin_anim_index = 0
                coin_anim_timer = current_time
                money_recevoir.play()
            money_time=False

            # Animation de la pièce
            if coin_anim_playing:
                if current_time - coin_anim_timer > coin_anim_interval:
                    coin_anim_index += 1
                    coin_anim_timer = current_time
                    if coin_anim_index >= len(coin_frames):
                        coin_anim_index = 0
                        coin_anim_playing = False
            else:
                coin_anim_index = 0

            # Affichage de la pièce
            coin_img = coin_frames[coin_anim_index]
            coin_rect = coin_img.get_rect(topleft=(int(413 * scale_x), int(10 * scale_y)))  # ajuste selon ton UI
            fake_screen.blit(coin_img, coin_rect)
            # Affichage du sprite de dégât si récemment touché
            if world.health != old_health:
                coeur_damaged = True
                die.play()
                coeur_damage_timer = pg.time.get_ticks()
                old_health = world.health

            if coeur_damaged:
                if current_time - coeur_damage_timer > 600:  # affiche le cœur "cassé" pendant 400 ms
                    coeur_damaged = False
                    old_health=world.health
                coeur_image = coeur_frames[3]  # frame 4 : cœur touché
            else:
                # Vitesse de battement selon les PV
                if world.health >= 7:
                    coeur_anim_interval = 500
                elif world.health >= 5:
                    coeur_anim_interval = 300
                elif world.health >= 3:
                    coeur_anim_interval = 200
                else:
                    coeur_anim_interval = 100

                if current_time - coeur_anim_timer > coeur_anim_interval:
                    coeur_anim_index = (coeur_anim_index + 1) % 3  # frames 0,1,2
                    coeur_anim_timer = current_time

                coeur_image = coeur_frames[coeur_anim_index]

            # Affiche le cœur animé
            coeur_rect = coeur_image.get_rect()
            coeur_rect.topleft = (int(460 * scale_x), int(11 * scale_y))  # position proche de ta vie
            fake_screen.blit(coeur_image, coeur_rect)
    pause_button.draw(fake_screen)


    if game_outcome in [-1, 1]:
        overlay = pg.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill((0, 0, 0))
        fake_screen.blit(overlay, (0, 0))

        if game_outcome == -1:
            text = "GAME OVER"
        elif game_outcome == 1:
            text = "YOU WIN"
            jouer_musique(musique_fin)

        pixel_font = pg.font.Font("minecraft_font.ttf", int(48 * scale_y))  # taille + grosse

        # Rendu et centrage
        text_surface = pixel_font.render(text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, int(80 * scale_y)))

        fake_screen.blit(text_surface, text_rect)

        bouton_rejouer.draw(fake_screen)
        bouton_quitter_fin.draw(fake_screen)


    if show_wave_banner:
        if pg.time.get_ticks() - wave_cleared_time < WAVE_BANNER_DURATION and world.level == 1:
            taille_fixe = 1290  # correspond à ton design original
            font = pg.font.SysFont(None, int(80*scale_y))  # Compense le zoom
            text_banniere = font.render(f"{world.level}", True, (255, 255, 255))
            fake_screen.blit(banniere_vague, (0,26*scale_y))
            fake_screen.blit(text_banniere, (int(270 * scale_x), int(26 * scale_y)))



        if pg.time.get_ticks() - wave_cleared_time < WAVE_BANNER_DURATION and world.level >1:
            WAVE_BANNER_DURATION = 2000
            taille_fixe = 1290  # correspond à ton design original
            font = pg.font.SysFont(None, int(80*scale_y))  # Compense le zoom
            text_banniere = font.render(f"{world.level}", True, (255, 255, 255))
            fake_screen.blit(banniere_vague, (0,26*scale_y))
            fake_screen.blit(text_banniere, (int(270 * scale_x), int(26 * scale_y)))

        if pg.time.get_ticks() - wave_cleared_time > WAVE_BANNER_DURATION:
            show_wave_banner=False







    if jeu_en_pause:
        # Fond semi-transparent
        display_data()
        overlay = pg.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill((0, 0, 0))
        fake_screen.blit(overlay, (0, 0))
        if pause_animation_active:
            if pause_animation_timer > PAUSE_ANIM_INTERVAL:
                pause_animation_timer = 0  # réinitialise le timer

                if animation_pause_frame < 9:
                    animation_pause_frame += 1

                elif animation_pause_frame == 9 and not pause_menu_active:
                    pause_menu_active = True


                elif animation_pause_frame >= 10 and animation_pause_frame < 17:
                    animation_pause_frame += 1
                elif animation_pause_frame == 17:
                    pg.mixer.music.unpause()
                    pause_animation_active = False
                    jeu_en_pause = False


        fake_screen.blit(pause_frames[animation_pause_frame], (132*scale_x, 0))



    screen.blit(pg.transform.scale(fake_screen, screen.get_rect().size), (0, 0))




# --- Animation ---

"""Dans le jeu il y a plusieurs animations , ses animations sont fait d'une grande image avec plusieurs images dedans
 nous allons les couper en plusieurs partie puis les stocker dans les listes pour les lires"""


placement_tourelle_sheet = pg.image.load(resource_path('assets/turret/placement_tourelle.png')).convert_alpha()
placement_tourelle_frames = []
for i in range(6):  # 6 frames horizontales
    frame = placement_tourelle_sheet.subsurface((i * 32, 0, 32, 32))  # adapte 32 si la taille est différente
    frame = pg.transform.scale(frame, (int(32 * scale_x), int(32 * scale_y)))
    placement_tourelle_frames.append(frame)

transition=False

# Initialisation pour animation GUI
map_gui_frames = []


frame_width = int(map_GUI.get_width() // 18)
frame_height = map_GUI.get_height()
for i in range(18):
    frame = map_GUI.subsurface(pg.Rect(i * frame_width, 0, frame_width, frame_height))
    # Redimensionnement individuel
    scaled_frame = pg.transform.scale(frame, (int(frame_width * scale_x), int(frame_height * scale_y)))
    map_gui_frames.append(scaled_frame)

map_gui_frame_index = 0
animation_in_progress = False
animation_reverse = False


windowed_size = (SCREEN_HEIGHT/2, SCREEN_WIDTH/2)

hWnd = win32gui.GetForegroundWindow()
oldWndProc = win32gui.SetWindowLong(hWnd, win32con.GWL_WNDPROC,
    lambda *args: wndProc(oldWndProc, draw_callback, *args))

hWnd = win32gui.GetForegroundWindow()
prev_rect = win32gui.GetWindowRect(hWnd)

##########

#////BOUCLE DU JEU/////

########


"""Pygame fonctionne autour d'une boucle qui va chercher des input par l'utilisateur jusqu'à qu'on ferme la fenêtre"""


while run == True :

    clock.tick(c.FPS) #Met le jeu en action avec des ticks par secondes
    pause_animation_timer += clock.get_time()


##########

# /////BOUCLE INPUT//////

##########


    for event in pg.event.get():
            if event.type == pg.QUIT:# ← Si on appuye sur la croix de la fenetre on quitte le jeu
                run = False

            if event.type == pg.KEYDOWN and event.key == pg.K_F11:
                fullscreen= not fullscreen
                if fullscreen:
                    prev_rect = win32gui.GetWindowRect(hWnd)
                    screen = pg.display.set_mode((0, 0), pg.FULLSCREEN | pg.DOUBLEBUF)
                    update_screen_scale()
                else:
                    fullscreen = False  # <-- assure le bon état

                    if first_windowed:
                        # Récupère la taille de l'écran actuel
                        screen_width = pg.display.Info().current_w
                        screen_height = pg.display.Info().current_h

                        # Calcule la taille réduite

                        new_width = screen_width // 2
                        new_height = int(new_width / RATIO)

                        # Centre la fenêtre à l'écran
                        screen = pg.display.set_mode((new_width, new_height), pg.RESIZABLE | pg.DOUBLEBUF)
                        hWnd = win32gui.GetForegroundWindow()
                        win32gui.SetWindowPos(
                            hWnd,
                            win32con.HWND_NOTOPMOST,
                            (screen_width - new_width) // 2,
                            (screen_height - new_height) // 2,
                            new_width,
                            new_height,
                            0
                            )
                        update_screen_scale()

                        first_windowed = False  # ✅ Ne le refait plus après
                    else:
                        # comportement normal après la 1re fois
                        screen = pg.display.set_mode((prev_rect[2] - prev_rect[0], prev_rect[3] - prev_rect[1]), pg.RESIZABLE | pg.DOUBLEBUF)
                        win32gui.SetWindowPos(
                            hWnd,
                            win32con.HWND_NOTOPMOST,
                            prev_rect[0],
                            prev_rect[1],
                            prev_rect[2] - prev_rect[0],
                            prev_rect[3] - prev_rect[1],
                            0
                            )
                        update_screen_scale()

            elif event.type == pg.VIDEORESIZE and not fullscreen:
                # Appliquer aussi ici pour mettre à jour screen
                new_width = event.w
                new_height = int(new_width / RATIO)
                screen = pg.display.set_mode((new_width, new_height), pg.RESIZABLE | pg.DOUBLEBUF)
                update_screen_scale()
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            if action == c.ACTMENU: #/////////////////////////////////////////
                if jouer_button.handle_event(event):# ← Démarrer le jeu
                    click.play()
                    musique_menu.fadeout(400)
                    fade_out(draw_menu, screen, 500)

                    transition= True
                    musique_en_cours = False
                    action = c.ACTRUN
                if options_button.handle_event(event):# ← Va dans les options du jeu
                    click.play()
                    musique_menu.fadeout(400)
                    fade_out(draw_menu, screen, 500)

                    intervenance=1
                    transition= True
                    action = c.ACTOPTION
                if quitter_button.handle_event(event):# ← Quitter le jeu
                    click.play()
                    run = False

            if action == c.ACTOPTION:#/////////////////////////////////////////
                if event.type == pg.MOUSEBUTTONDOWN:
                    if Bouton_retour.collidepoint(event.pos):
                        bouton_metal.play()
                        volume_temp = volume_saved
                        volume_temp_musique = volume_saved_musique
                        volume_temp_defenses = volume_saved_defenses
                        volume_temp_effets = volume_saved_effets
                        volume_general = volume_temp / 9
                        retour_cliqué=True
                        musique_option.fadeout(400)
                        fade_out(draw_options, screen, 500)
                        transition= True
                        retour_cliqué=False
                        if intervenance == 1:
                            action = c.ACTMENU
                        else:
                            musique_pause.play(loops=-1, fade_ms=500)
                            action = c.ACTRUN
                    if changement_detecté == True:
                        if appliquer_rect.collidepoint(event.pos):
                            anul_appliq.play()
                            volume_saved = volume_temp
                            volume_saved_musique = volume_temp_musique
                            volume_saved_defenses = volume_temp_defenses
                            volume_saved_effets = volume_temp_effets
                            volume_slider_pos = volume_temp  # on valide
                            volume_general = volume_temp / 9
                            appliquer_volumes()
                            changement_detecté = False


                        if annuler_rect.collidepoint(event.pos):
                            anul_appliq.play()
                            volume_temp = volume_saved
                            volume_temp_musique = volume_saved_musique
                            volume_temp_defenses = volume_saved_defenses
                            volume_temp_effets = volume_saved_effets
                            volume_general = volume_temp / 9
                            appliquer_volumes()
                            changement_detecté = False


                    else:
                        if annuler_rect.collidepoint(event.pos):
                            refuse.play()
                        if appliquer_rect.collidepoint(event.pos):
                            refuse.play()

                    mouse_x, mouse_y = event.pos
                    # Vérifie si clic proche du slider
                    for i in range(10):
                        x = slider_start_x + i * slider_spacing
                        if abs(mouse_x - x) <= 9 and abs(mouse_y - slider_y) <= 9:

                            volume_temp = i  # Met à jour la valeur temporaire
                            volume_general = volume_temp / 9
                            appliquer_volumes()
                            slider_drag_general = True

                    # Slider musique
                    if abs(mouse_y - slider_y_musique) <= 10:
                        for i in range(10):
                            x = slider_start_x + i * slider_spacing
                            if abs(mouse_x - x) <= 10:

                                volume_temp_musique = i
                                volume_musique = i / 9
                                appliquer_volumes()
                                slider_drag_general = True

                    # Slider défenses
                    if abs(mouse_y - slider_y_defenses) <= 10:
                        for i in range(10):
                            x = slider_start_x + i * slider_spacing
                            if abs(mouse_x - x) <= 10:

                                volume_temp_defenses = i
                                volume_defenses = i / 9
                                appliquer_volumes()
                                slider_drag_general = True

                    # Slider effets
                    if abs(mouse_y - slider_y_effets) <= 10:
                        for i in range(10):
                            x = slider_start_x + i * slider_spacing
                            if abs(mouse_x - x) <= 10:

                                volume_temp_effets = i
                                volume_effets = i / 9
                                appliquer_volumes()
                                slider_drag_general = True




                    if bouton_pleine_ecran.collidepoint(event.pos):
                        if fullscreen == False:
                            fullscreen = True
                            pleine_écran_cliqué=True
                            prev_rect = win32gui.GetWindowRect(hWnd)
                            screen = pg.display.set_mode((0, 0), pg.FULLSCREEN | pg.DOUBLEBUF)
                            update_screen_scale()
                            pleine_écran_cliqué=False



                    if bouton_fenetre.collidepoint(event.pos):
                        fullscreen = False  # <-- assure le bon état

                        if first_windowed:
                            # Récupère la taille de l'écran actuel
                            screen_width = pg.display.Info().current_w
                            screen_height = pg.display.Info().current_h

                            # Calcule la taille réduite
                            new_width = screen_width // 2
                            new_height = int(new_width / RATIO)

                            # Centre la fenêtre à l'écran
                            screen = pg.display.set_mode((new_width, new_height), pg.RESIZABLE | pg.DOUBLEBUF)
                            hWnd = win32gui.GetForegroundWindow()
                            win32gui.SetWindowPos(
                                hWnd,
                                win32con.HWND_NOTOPMOST,
                                (screen_width - new_width) // 2,
                                (screen_height - new_height) // 2,
                                new_width,
                                new_height,
                                0
                            )
                            update_screen_scale()
                            first_windowed = False  # Ne le refait plus après
                        else:
                            # comportement normal après la 1re fois
                            screen = pg.display.set_mode((prev_rect[2] - prev_rect[0], prev_rect[3] - prev_rect[1]), pg.RESIZABLE | pg.DOUBLEBUF)
                            win32gui.SetWindowPos(
                                hWnd,
                                win32con.HWND_NOTOPMOST,
                                prev_rect[0],
                                prev_rect[1],
                                prev_rect[2] - prev_rect[0],
                                prev_rect[3] - prev_rect[1],
                                0
                            )
                            update_screen_scale()


                if pg.mouse.get_pressed()[0]:
                    mouse_x, mouse_y = pg.mouse.get_pos()
                    relative_x = mouse_x - slider_start_x
                    index = round(relative_x / slider_spacing)

                    if 0 <= index <= 9:
                        if abs(mouse_y - slider_y_musique) <= 10:
                            if index != volume_temp_musique:
                                volume_temp_musique = index
                                volume_musique = index / 9
                                dec_son.play()
                                changement_detecté=True
                        elif abs(mouse_y - slider_y_defenses) <= 10:
                            if index != volume_temp_defenses:
                                volume_temp_defenses = index
                                volume_defenses = index / 9
                                dec_son.play()
                                changement_detecté=True
                        elif abs(mouse_y - slider_y_effets) <= 10:
                            if index != volume_temp_effets:
                                volume_temp_effets = index
                                volume_effets = index / 9
                                dec_son.play()
                                changement_detecté=True
                        elif abs(mouse_y - slider_y) <= 10:
                            if index != volume_temp:
                                volume_temp = index
                                volume_general = index / 9
                                dec_son.play()
                                changement_detecté=True

                        appliquer_volumes()

                if event.type == pg.MOUSEBUTTONUP:
                    slider_drag_general = False
                    slider_drag_musique = False
                    slider_drag_defenses = False
                    slider_drag_effets = False


            if action == c.ACTRUN : #///////////////////////////////////////
                if level_started == False:
                    if event.type == pg.MOUSEBUTTONDOWN:
                        if Bouton_Commencer.collidepoint(event.pos):
                            trompette_de_guerre.play()
                            foret.fadeout(2000)
                            level_started = True
                            animation_in_progress = True
                            map_gui_frame_index = 0  # Recommencer l’animation
                            pg.mixer.music.play(loops=-1)
                            # === Afficher le bandeau "Vague 1" ===
                            wave_cleared_time = pg.time.get_ticks()
                            show_wave_banner = True
                if bouton_vendre.handle_event(event):
                            if selected_turret:
                                if selected_turret.emplacement_id in liste_des_defences_deja_utilisé:
                                    liste_des_defences_deja_utilisé.remove(selected_turret.emplacement_id)

                                if selected_turret_type == "defense":
                                    vendre_kashing.play()
                                    world.money += int(c.PRIX_COLOSSE/2)
                                elif selected_turret_type == "artillerie":
                                    world.money += int(c.PRIX_ARTILLERIE/2)

                                    vendre_kashing.play()
                                elif selected_turret_type == "lancier":
                                    vendre_kashing.play()
                                    world.money += int(c.PRIX_LANCIER/2)
                                selected_turret.kill()
                                selected_turret = None
                                clear_selection()
                            else:
                                refuse.play()

                if event.type == pg.MOUSEBUTTONDOWN and event.button == 1 :
                    mouse_pos = pg.mouse.get_pos()
                    #verifier si la souris est dans la zone de jeu
                    if mouse_pos[0]< SCREEN_WIDTH*scale_x and mouse_pos[1] <SCREEN_HEIGHT*scale_y:
                        #efface les selection des defences
                        selected_turret = None
                        clear_selection()
                        if placing_turrets == True:
                            if selected_turret_type == "defense":
                                ghost_turret_sprite =None
                                prix = c.PRIX_COLOSSE
                            elif selected_turret_type == "artillerie":
                                ghost_turret_sprite =None
                                prix = c.PRIX_ARTILLERIE
                            elif selected_turret_type == "lancier":
                                ghost_turret_sprite =None
                                prix = c.PRIX_LANCIER
                            else:
                                prix = 9999

                            if world.money >= prix:
                                create_turret(mouse_pos, selected_turret_type)

                        else:
                            selected_turret = select_turret(mouse_pos)

                if not jeu_en_pause :
                    if pause_button.handle_event(event):
                        placing_turrets=False
                        foret.fadeout(400)
                        engrenage.play()
                        pause_amb.play()
                        musique_pause.play(loops=-1, fade_ms=500)
                        pause_menu_active = False
                        pause_animation_active = True
                        animation_pause_frame = 0
                        jeu_en_pause = True
                        ghost_turret_sprite =None
                        volume_en_pause = pg.mixer.music.get_volume()
                        pg.mixer.music.pause()

                    if placing_turrets == False:
                        if colosse_button.handle_event(event):
                            selected_turret_type = "defense"
                            if world.money >= c.PRIX_COLOSSE:
                                defense_click.play()

                                placing_turrets = True
                                ghost_turret_sprite = cursor_turret
                                ghost_range_frames = range_animations_by_type["defense"]
                                ghost_range_index = 0
                                placement_angle = 0

                            else:
                                refuse.play()

                        if artillerie_button.handle_event(event):
                            selected_turret_type = "artillerie"
                            if world.money >= c.PRIX_ARTILLERIE:
                                defense_click.play()
                                placing_turrets = True
                                ghost_turret_sprite = cursor_turret_artillerie
                                ghost_range_frames = range_animations_by_type["artillerie"]
                                ghost_range_index = 0
                                placement_angle = 0
                            else:
                                refuse.play()

                        if legionnaire_button.handle_event(event):
                            selected_turret_type = "lancier"
                            if world.money >= c.PRIX_LANCIER:
                                defense_click.play()
                                placing_turrets = True
                                ghost_turret_sprite = cursor_turret_lancier
                                ghost_range_frames = range_animations_by_type["lancier"]
                                ghost_range_index = 0
                                placement_angle = 0

                            else:
                                refuse.play()


                        if cancel_button.handle_event(event):
                            refuse.play()
                    else:

                        if cancel_button.handle_event(event):
                            defense_annule_click.play()
                            placing_turrets = False
                            ghost_turret_sprite =None

                    if game_over == True:
                        if game_outcome in [-1, 1]:
                            if bouton_rejouer.handle_event(event):
                                click.play()
                                # Réinitialise le jeu
                                game_over = False
                                musique_en_cours = False
                                level_started = False
                                placing_turrets = False
                                selected_turret = None
                                last_enemy_spawn = pg.time.get_ticks()
                                enemy_group.empty()
                                turret_group.empty()
                                world.projectile_group.empty()
                                liste_des_defences_deja_utilisé = []
                                map_gui_frame_index = 0
                                animation_reverse = False
                                animation_in_progress = False
                                jeu_en_pause = False
                                pause_animation_active = False
                                pause_menu_active = False
                                animation_pause_frame = 0
                                world = World(world_data, map_image)
                                world.process_data(scale_x, scale_y)
                                world.process_enemies()
                                world.money = 300
                                world.health = 10
                                world.level = 1
                                game_outcome = 0  # remettre à zéro
                                mamoth_sound==False
                                next_enemy_spawn_delay = int(random.uniform(0.4, 1) * 1000)
                                WAVE_BANNER_DURATION = 3500
                                c.difficulté=1

                            if bouton_quitter_fin.handle_event(event):
                                click.play()
                                run = False

                else:
                    if event.type == pg.MOUSEBUTTONDOWN and pause_menu_active:
                        if bouton_retour_pause.collidepoint(event.pos):
                            rock.play()
                            ferm_pause.play()
                            musique_pause.fadeout(400)
                            if level_started == False:

                                foret.play(loops=-1, fade_ms=500)


                            pause_menu_active = False
                            pause_animation_active = True
                            animation_pause_frame = 10
                        if bouton_options_pause.collidepoint(event.pos):
                            rock.play()
                            musique_pause.fadeout(400)
                            fade_out(draw_run, screen, 500)
                            intervenance=2
                            transition= True
                            action = c.ACTOPTION
                        if bouton_menu_pause.collidepoint(event.pos):
                            rock.play()
                            musique_pause.fadeout(400)
                            fade_out(draw_run, screen, 500)
                            transition = True
                            game_over = False
                            level_started = False
                            placing_turrets = False
                            selected_turret = None
                            last_enemy_spawn = pg.time.get_ticks()
                            enemy_group.empty()
                            turret_group.empty()
                            turret_group.empty()
                            liste_des_defences_deja_utilisé = []
                            map_gui_frame_index = 0
                            animation_reverse = False
                            animation_in_progress = False
                            jeu_en_pause = False
                            pause_animation_active = False
                            pause_menu_active = False
                            animation_pause_frame = 0
                            action = c.ACTMENU
                            world.money = 300
                            world.health = 10
                            world.level = 1
                            world.wave_index = 0
                            world.spawned_enemies = []
                            world.process_enemies()
                            world = World(world_data, map_image)
                            world.process_data(scale_x,scale_y)
                            world.process_enemies()
                            world.projectile_group.empty()
                            mamoth_sound==False
                            next_enemy_spawn_delay = int(random.uniform(0.4, 1) * 1000)
                            WAVE_BANNER_DURATION = 3500
                            c.difficulté=1








##########

# /////AUTRES//////

##########

    if action == c.ACTMENU: #/////////Espace menu
        appliquer_volumes()
        draw_menu()
        jouer_musique(musique_menu)


        if transition:
            fade_in(draw_menu, screen, 500)

            transition= False



    if action == c.ACTOPTION: #////////Espace Options
        draw_options()
        jouer_musique(musique_option)



        if transition:
            fade_in(draw_options, screen, 500)

            transition= False



    if action == c.ACTRUN: #/////////Espace Jeu en cours
        draw_run()
        jouer_musique(foret)

        if transition:
            fade_in(draw_run, screen, 500)
            transition= False

        if not jeu_en_pause and not game_over:
            if level_started == True:
                #Vitesse du jeu
                keys = pg.key.get_pressed()
                if keys[pg.K_SPACE]:
                    world.game_speed = 2
                    fake_screen.blit(map_gui_frames[min(map_gui_frame_index+1, 17)], (int(375*scale_x), 0))
                    display_data()

                else:
                    world.game_speed = 1

                #Apparitions des ennemies
                if show_wave_banner == False:
                    if pg.time.get_ticks() - last_enemy_spawn > next_enemy_spawn_delay / world.game_speed:
                        if world.spawned_enemies < len(world.enemy_list):
                            enemy_type = world.enemy_list[world.spawned_enemies]
                            enemy = Enemy(enemy_type, world.waypoints, enemy_images, scale_x, scale_y, death_sheet, on_death=play_enemy_death_sound)
                            enemy_group.add(enemy)
                            world.spawned_enemies += 1
                            last_enemy_spawn = pg.time.get_ticks()

                            # Délai aléatoire entre 200 et 600 ms
                            if world.level <= 3:
                                next_enemy_spawn_delay = int(random.uniform(0.4, 1) * 1000)
                            elif world.level >= 3:
                                next_enemy_spawn_delay = int(random.uniform(0.3, 0.9) * 1000)
                            elif world.level >= 5:
                                next_enemy_spawn_delay = int(random.uniform(0.25, 0.8) * 1000)
                            elif world.level >= 7:
                                next_enemy_spawn_delay = int(random.uniform(0.2, 0.5) * 1000)
                            elif world.level >= 9:
                                next_enemy_spawn_delay = int(random.uniform(0.2, 0.3) * 1000)

            #observe si le joueur a perdu
            if world.health <= 0:
                game_over = True
                animation_in_progress = True
                animation_reverse = True
                map_gui_frame_index = 8
                game_outcome = -1 # perdu
            #observe si le joeur a gagné
            if world.level > c.TOTAL_LEVELS:
                game_over = True
                animation_reverse = True
                game_outcome = 1 #win


            #modifier les groupes
            enemy_group.update(world)
            turret_group.update(enemy_group, world)
            world.projectile_group.update(world, enemy_group)

            #Surligne les défences séléctionné
            if selected_turret:
                selected_turret.selected = True


        placement_anim_timer += clock.get_time()
        if placement_anim_timer > PLACEMENT_ANIM_INTERVAL:
            placement_anim_index = (placement_anim_index + 1) % len(placement_tourelle_frames)
            placement_anim_timer = 0




        if world.level == 5 and mamoth_sound==False:
            mamouth.play()
            mamoth_sound=True
        #observe si la vague est terminé
        if world.check_level_complete():
            world.level += 1
            c.difficulté+=0.18
            money_time= True

            # ➕ Si on dépasse les vagues disponibles, alors victoire
            if world.level > len(world.enemy_list_by_level):  # ⬅ adapte ce nom selon ton code
                game_over = True
                animation_in_progress = True
                animation_reverse = True
                map_gui_frame_index = 8
                game_outcome = 1  # victoire
                jouer_musique(musique_fin)
            else:
                world.money += c.LEVEL_COMPLETE_REWARD
                last_enemy_spawn = pg.time.get_ticks()
                world.reset_level()
                world.process_enemies()

                # Affichage du bandeau de vague suivante
                wave_cleared_time = pg.time.get_ticks()
                show_wave_banner = True



    #Update l'écran

    pg.display.flip()


pg.quit()
