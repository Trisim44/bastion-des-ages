import constants as c
ENEMY_SPAWN_DATA = [
    {
        #1
        "weak" : 3,
        "medium" : 0,
        "strong" : 0
    },
    {
        #2
        "weak" : 8,
        "medium" : 0,
        "strong" : 0
    },
    {
        #3
        "weak" : 10,
        "medium" : 3,
        "strong" : 0
    },
    {
        #4
        "weak" :20,
        "medium" : 8,
        "strong" : 0
    },
    {
        #5
        "weak" : 10,
        "medium" : 15,
        "strong" : 1
    },
    {
        #6
        "weak" : 15,
        "medium" : 20,
        "strong" : 3
    },
    {
        #7
        "weak" : 30,
        "medium" : 25,
        "strong" : 6
    },
    {
        #8
        "weak" : 0,
        "medium" : 30,
        "strong" : 10
    },
    {
        #9
        "weak" : 0,
        "medium" : 60,
        "strong" : 15
    },
    {
        #10
        "weak" : 200,
        "medium" : 50,
        "strong" : 30
    },
]

def get_enemy_data():
    return {
        "weak": {
            "health": int(20 * c.difficulté),
            "speed": 2.5
        },
        "medium": {
            "health": int(35 * c.difficulté),
            "speed": 4
        },
        "strong": {
            "health": int(200 * c.difficulté),
            "speed": 2
        },
        "elite": {
            "health": 1000,
            "speed": 6
        },
    }